// TailorPro JavaScript modules are loaded from index.html in dependency order.
