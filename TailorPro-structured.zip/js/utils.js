function showToast(msg,type='success'){const t=document.getElementById('toast');document.getElementById('toastMsg').textContent=msg;t.className='toast '+type;t.querySelector('i').className=type==='success'?'fas fa-check-circle':type==='error'?'fas fa-exclamation-circle':'fas fa-info-circle';t.classList.add('show');setTimeout(()=>t.classList.remove('show'),3000)}
function closeModal(id){document.getElementById(id).classList.remove('active')}
function openModal(id){document.getElementById(id).classList.add('active')}
function formatMoney(n){return Number(n).toLocaleString('ar-SA')}
function formatDate(d){if(!d)return'-';const date=new Date(d);return date.toLocaleDateString('ar-SA')}
function getStatusBadge(status){const map={new:'<span class="status-badge status-new">جديد</span>',processing:'<span class="status-badge status-processing">تحت التفعيل</span>',ready:'<span class="status-badge status-ready">جاهز</span>',delivered:'<span class="status-badge status-delivered">تم التسليم</span>',cancelled:'<span class="status-badge status-cancelled">ملغي</span>'};return map[status]||status}
