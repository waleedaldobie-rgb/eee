async function renderDashboard(){
const orders=await getAll('orders');
const fabrics=await getAll('fabrics');
const notifications=await getAll('notifications');
const totalSales=orders.filter(o=>o.status==='delivered').reduce((s,o)=>s+o.total,0);
const delivered=orders.filter(o=>o.status==='delivered').length;
const ready=orders.filter(o=>o.status==='ready').length;
const newOrders=orders.filter(o=>o.status==='new').length;
document.getElementById('dashTotalSales').textContent=formatMoney(totalSales);
document.getElementById('dashDelivered').textContent=delivered;
document.getElementById('dashReady').textContent=ready;
document.getElementById('dashNew').textContent=newOrders;

const lowStock=[...fabrics.filter(f=>f.quantity<=f.minStock),...(await getAll('accessories')).filter(a=>a.quantity<=a.minStock)];
const alertDiv=document.getElementById('lowStockAlert');
if(lowStock.length>0){alertDiv.classList.remove('hidden');document.getElementById('lowStockList').innerHTML=lowStock.map(f=>`<li class="flex items-center gap-2"><i class="fas fa-circle text-[6px] text-amber-500"></i> ${f.name} – متبقي <strong>${f.quantity}</strong> من أصل ${f.minStock}</li>`).join('');}
else{alertDiv.classList.add('hidden');}

const recent=orders.slice(-5).reverse();
document.getElementById('recentOrdersList').innerHTML=recent.length?`<table><thead><tr><th>رقم الطلب</th><th>العميل</th><th>النوع</th><th>المبلغ</th><th>الحالة</th></tr></thead><tbody>${recent.map(o=>`<tr><td class="font-bold text-slate-700">ORD-${String(o.id).padStart(4,'0')}</td><td><div class="font-medium text-slate-700">${o.customerName}</div></td><td>${o.type}</td><td class="font-bold text-slate-800">${formatMoney(o.total)} <span class="text-xs text-slate-400">ر.ي</span></td><td>${getStatusBadge(o.status)}</td></tr>`).join('')}</tbody></table>`:'<div class="empty-state"><i class="fas fa-inbox"></i><p>لا توجد طلبات</p></div>';

const recentNotif=notifications.slice(-5).reverse();
document.getElementById('recentNotifications').innerHTML=recentNotif.map(n=>{const icon=n.type==='whatsapp'?'fab fa-whatsapp':'fas fa-exclamation-triangle';const bg=n.type==='whatsapp'?'bg-emerald-50 border border-emerald-100':'bg-amber-50 border border-amber-100';const iconBg=n.type==='whatsapp'?'bg-emerald-500':'bg-amber-500';return `<div class="flex items-start gap-3 p-3.5 ${bg} rounded-xl"><div class="w-9 h-9 ${iconBg} rounded-full flex items-center justify-center text-white text-xs flex-shrink-0 shadow-sm"><i class="${icon}"></i></div><div class="flex-1"><p class="text-sm text-slate-700 font-medium leading-relaxed">${n.message}</p><p class="text-xs text-slate-400 mt-1">${formatDate(n.createdAt)}</p></div></div>`;}).join('');

const unread=notifications.filter(n=>!n.isRead).length;
document.getElementById('notifBadge').classList.toggle('hidden',unread===0);
}

let selectedCustomerId=null;
