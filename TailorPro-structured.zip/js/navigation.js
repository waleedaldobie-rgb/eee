function showPage(pageId){
document.querySelectorAll('.page').forEach(p=>p.classList.remove('active'));
document.getElementById(pageId).classList.add('active');
document.querySelectorAll('.nav-item').forEach(n=>n.classList.remove('active'));
document.getElementById('nav-'+pageId).classList.add('active');
const titles={dashboard:'لوحة التحكم',customers:'العملاء والمقاسات',orders:'الطلبات والفواتير',inventory:'المخزون والأقمشة',reports:'التقارير والأرباح',employees:'إدارة الموظفين'};
const subtitles={dashboard:'نظرة شاملة على أداء المحل',customers:'إدارة بيانات العملاء ومقاساتهم',orders:'متابعة طلبات التفصيل وإدارة المدفوعات',inventory:'تتبع كميات الأقمشة والمستلزمات',reports:'تحليل أداء المحل والمبيعات والأرباح',employees:'إضافة وتعديل وحذف حسابات الموظفين'};
document.getElementById('page-title').textContent=titles[pageId];
document.getElementById('page-subtitle').textContent=subtitles[pageId];
if(pageId==='dashboard')renderDashboard();
if(pageId==='customers')renderCustomers();
if(pageId==='orders')renderOrders();
if(pageId==='inventory')renderInventory();
if(pageId==='reports')renderReports();
if(pageId==='employees')renderEmployees();
}

