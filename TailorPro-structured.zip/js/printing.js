async function printInvoice(orderId){
const o=await getById('orders',orderId);if(!o)return;
const{jsPDF}=window.jspdf;
const doc=new jsPDF({unit:'mm',format:[80,180]});
doc.setFillColor(37,99,235);doc.rect(0,0,80,18,'F');
doc.setTextColor(255,255,255);doc.setFontSize(16);doc.text('الخياط برو',40,12,{align:'center'});
doc.setTextColor(100,116,139);doc.setFontSize(8);doc.text('نظام إدارة القمصان',40,22,{align:'center'});
doc.setDrawColor(226,232,240);doc.line(5,26,75,26);
doc.setTextColor(15,23,42);doc.setFontSize(11);doc.text('فاتورة طلب تفصيل',40,34,{align:'center'});
doc.setFontSize(9);doc.setTextColor(71,85,105);
doc.text('رقم الطلب: ORD-'+String(o.id).padStart(4,'0'),5,44);
doc.text('العميل: '+o.customerName,5,50);
doc.text('الجوال: '+o.customerPhone,5,56);
doc.text('النوع: '+o.type,5,62);
doc.text('القماش: '+(o.fabricName||'')+' - '+o.color,5,68);
doc.text('تاريخ الطلب: '+formatDate(o.orderDate),5,74);
doc.text('تاريخ التسليم: '+formatDate(o.deliveryDate),5,80);
doc.setDrawColor(226,232,240);doc.line(5,86,75,86);
doc.setFontSize(10);doc.setTextColor(15,23,42);doc.text('المبلغ الإجمالي:',5,96);doc.text(formatMoney(o.total)+' ر.ي',75,96,{align:'right'});
doc.setTextColor(100,116,139);doc.text('العربون:',5,104);doc.text(formatMoney(o.paid)+' ر.ي',75,104,{align:'right'});
doc.setTextColor(o.remaining>0?220:16,o.remaining>0?38:185,o.remaining>0?38:129);doc.setFontSize(11);doc.text('المتبقي:',5,114);doc.text(formatMoney(o.remaining)+' ر.ي',75,114,{align:'right'});
doc.setDrawColor(226,232,240);doc.line(5,122,75,122);
doc.setTextColor(148,163,184);doc.setFontSize(8);doc.text('شكراً لثقتكم بنا',40,132,{align:'center'});
doc.save('invoice_ORD_'+String(o.id).padStart(4,'0')+'.pdf');
showToast('تم تحميل الفاتورة');
}

async function printQuotation(orderId){
const o=await getById('orders',orderId);if(!o)return;
const{jsPDF}=window.jspdf;
const doc=new jsPDF({unit:'mm',format:[80,150]});
doc.setFillColor(245,158,11);doc.rect(0,0,80,18,'F');
doc.setTextColor(255,255,255);doc.setFontSize(16);doc.text('الخياط برو',40,12,{align:'center'});
doc.setTextColor(100,116,139);doc.setFontSize(8);doc.text('عرض سعر تقديري',40,22,{align:'center'});
doc.setDrawColor(226,232,240);doc.line(5,26,75,26);
doc.setTextColor(15,23,42);doc.setFontSize(11);doc.text('عرض سعر',40,34,{align:'center'});
doc.setFontSize(9);doc.setTextColor(71,85,105);
doc.text('العميل: '+o.customerName,5,44);
doc.text('النوع: '+o.type,5,52);
doc.text('القماش: '+(o.fabricName||'')+' - '+o.color,5,60);
doc.setDrawColor(226,232,240);doc.line(5,68,75,68);
doc.setFontSize(14);doc.setTextColor(245,158,11);doc.text('المبلغ التقديري:',5,82);doc.text(formatMoney(o.total)+' ر.ي',75,82,{align:'right'});
doc.setFontSize(8);doc.setTextColor(148,163,184);doc.text('هذا عرض سعر تقديري وقد يتغير حسب المواصفات النهائية',40,94,{align:'center'});
doc.text('شكراً لثقتكم بنا',40,110,{align:'center'});
doc.save('quotation_ORD_'+String(o.id).padStart(4,'0')+'.pdf');
showToast('تم تحميل عرض السعر');
}
